# OmniFlow — Professional Four-Bed Dashboard

## Run
1. Extract the ZIP.
2. Open a terminal in the extracted folder.
3. Run `python -m http.server 8000`.
4. Open `http://localhost:8000` in Chrome or Edge.
5. Press Start Camera and allow camera access.

## Features
- Four individually selectable bed cards with levels, flow estimates and status
- Animated IV drip / flow-rate visualization (illustrative only)
- Camera preview with ROI overlay and camera/resolution controls
- Patient reference and nurse assignment (local demo only)
- Fluid trend chart and ward summary
- Alert acknowledge/resolve/filter workflow
- Four-channel camera readiness matrix
- CSV bed report and audit-log export
- Theme toggle, configurable demo thresholds, refresh preference
- Audit trail and system health panel

## Important limitations
This is a frontend prototype. The bed readings and trends are demo values, not live AI measurements. Only one browser webcam stream is connected; the other camera tiles are readiness placeholders. No AI model, actual sensor, clinical validation, database persistence, nurse notifications, or infusion-device control is connected. Do not use this prototype for patient care.

## v2 additions
- Hamburger navigation (≤900px), real-time form validation, toast notifications, skeleton loaders and button spinners
- Searchable / sortable / paginated Bed register and Audit log tables
- Per-bed fluid type, bag volume and **alert-at-mL** threshold (presets per fluid, fully adjustable)
- Air-in-line and line-pressure (occlusion) sensing; new alert types: Air bubble, Occlusion, Flow drift
- Simulated smart pump (`PumpAdapter.send()`): auto-pause on bubble/occlusion/near-empty, auto-slow when low
- Per-bed nurse-change countdown (amber ≤30 min, red ≤10 min) and flow-rate drift detection (± tolerance %)
- Simulation mode: start/pause, 1×/10×/60× speed, inject bubble / occlusion / drift / near-empty

All sensor, pressure and pump behaviour is **simulated**. No real pump is controlled.

## v3 additions
- Reliable alarms (Web Audio, enabled by tapping the header sound button) with 3 priorities: urgent / warning / routine; unacknowledged alerts repeat at a set interval
- Voice announcements: half-empty, empty, air bubble, blocked line, broken/disconnected line (browser speech synthesis)
- Scan IV bag QR/barcode with the camera (BarcodeDetector) or paste `OMNI|bagId|fluid|volumeMl|patientRef|medication` to link a bag to a bed
- Scrolling live-status cards, animated alert ticker and general tips
- Follow-up module: appointments with reminders, recovery check-ins with chart, progress report CSV (saved in browser localStorage)


## v3.1 reliability fixes
- Removed random per-second flow-rate jitter that could create false flow-drift alerts.
- Voice announcements for half-empty and empty bags trigger on actual threshold crossings, not simply because an already-low bag exists on page load.
- Initial demo beds initialize their announcement state to avoid unsolicited startup speech.
- Speech output is prevented from stacking up over itself; urgent messages can interrupt the current announcement.
- These are simulation reliability improvements only. The dashboard is not a medical device and must not be used for patient care.


## v3.2 Smart Priority Alarm System
- Automatic priority classification: urgent for critical IV/air/occlusion/line alerts and near-term low-fluid events; routine for low-fluid/flow-drift reminders; low priority for informational events.
- Each active alert includes a priority selector (Auto, Urgent, Routine, Low) so an operator can override the automatic choice.
- Urgent alerts use a stronger repeating tone and browser vibration where supported; routine alerts use a moderate chime; low priority alerts use a soft tone and subtle vibration where supported.
- Pending urgent alerts suppress repeat sounds for routine and low-priority alerts until the urgent item is acknowledged or resolved.
- Duplicate active alert types are grouped by bed/type, and alerts repeat only while pending. Enabling sound alone is silent; no active alert means no alarm is played.
- Browser sound must be enabled by a user gesture. Vibration depends on browser/device support. This remains a demonstration prototype and is not for clinical use.

## v3.2 integrated priority workflow (revised)
- All IV safety events and follow-up appointment reminders appear in the same active alert manager.
- Auto-priority is recalculated from the current condition/time remaining. An appointment is low priority outside 30 minutes, routine inside 30 minutes, and urgent once due or overdue. This rule applies when the appointment reminder window has opened; earlier appointments do not generate alerts.
- The dropdown in either the appointment register or the active alert manager persists an appointment's manual priority override in browser localStorage. Bed-alert manual overrides last for the current active occurrence.
- Unacknowledged urgent alerts replay at the configured interval, subject to user-enabled audio; medium/low alerts sound at most once per newly created alert. Urgent pending alerts suppress non-urgent sounds, speech, and vibration. Acknowledging or resolving the urgent alert stops future repeats.
- Duplicate alert instances stay grouped by bed + condition or appointment ID. Resolving an IV alert will not re-open it until the condition actually clears and later reoccurs.
- With no pending active items, no alert sound/vibration is produced. Enabling sound does not itself play a tone. Explicit sound/voice test buttons in settings remain user-triggered demonstrations.

### Test the workflow
1. Start the local server, open the dashboard, and enable sound through a click (required by browsers).
2. Use the simulation controls to inject an air bubble or occlusion. Verify an **Urgent** alert appears; acknowledge it and confirm urgent repeating tones stop.
3. Create a follow-up appointment with a reminder window that begins shortly, and verify its alert appears under **Alert Management**, where you can change priority, acknowledge, and resolve it.
4. Switch the appointment override to **Routine** or **Low** and verify it does not repeatedly sound, even with the app open.
5. Resolve all active demo alerts, disable simulation, and verify no further alert sounds or vibrations occur. Note that demo bed conditions must actually clear before a new alert instance can be created.

**Safety:** This is a browser-only simulation, not a clinically certified alarm. Background tabs, sleep mode, browser autoplay rules, vibration support, and closed browsers can prevent notifications. There is no operating-system or server-side alert-delivery guarantee. Never depend on it for actual emergency or medication alerts.
